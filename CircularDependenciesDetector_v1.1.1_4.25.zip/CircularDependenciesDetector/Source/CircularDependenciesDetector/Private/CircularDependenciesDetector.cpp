// Copyright 2020 bstt, Inc. All Rights Reserved.

#include "CircularDependenciesDetector.h"

#define LOCTEXT_NAMESPACE "FCircularDependenciesDetectorModule"

void FCircularDependenciesDetectorModule::StartupModule()
{

}

void FCircularDependenciesDetectorModule::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FCircularDependenciesDetectorModule, CircularDependenciesDetector)